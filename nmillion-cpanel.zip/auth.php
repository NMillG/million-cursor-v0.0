<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function require_guest(): void
{
    if (is_logged_in()) {
        header('Location: dashboard.php');
        exit;
    }
}

function require_auth(): void
{
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function csrf_ensure(): void
{
    if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token']) || $_SESSION['csrf_token'] === '') {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

function csrf_token(): string
{
    csrf_ensure();
    return (string)$_SESSION['csrf_token'];
}

function csrf_verify(?string $token): bool
{
    csrf_ensure();
    if ($token === null || $token === '') {
        return false;
    }
    return hash_equals((string)$_SESSION['csrf_token'], $token);
}

function current_user_email(): string
{
    return strtolower(trim((string)($_SESSION['user_email'] ?? '')));
}

function admin_email_list(): array
{
    $raw = trim((string)ADMIN_EMAILS);
    if ($raw === '') {
        return [];
    }
    $parts = preg_split('/[,\s;]+/', $raw) ?: [];
    $out = [];
    foreach ($parts as $p) {
        $p = strtolower(trim((string)$p));
        if ($p !== '') {
            $out[] = $p;
        }
    }
    return array_values(array_unique($out));
}

function is_admin(): bool
{
    $email = current_user_email();
    if ($email === '') {
        return false;
    }
    return in_array($email, admin_email_list(), true);
}

function require_admin(): void
{
    require_auth();
    if (!is_admin()) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

function verify_recaptcha(string $token): bool
{
    if ($token === '') {
        return false;
    }

    $postData = http_build_query([
        'secret' => RECAPTCHA_SECRET_KEY,
        'response' => $token,
    ]);

    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\n",
            'content' => $postData,
            'timeout' => 8,
        ],
    ]);

    $response = @file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
    if ($response === false) {
        return false;
    }

    $json = json_decode($response, true);
    return is_array($json) && !empty($json['success']);
}

function flash_set(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function flash_get(): ?array
{
    if (!isset($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}
