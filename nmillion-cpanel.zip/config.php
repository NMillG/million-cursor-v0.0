<?php
declare(strict_types=1);

/**
 * Read environment variable with fallback.
 */
function env_or(string $key, string $fallback): string
{
    $value = getenv($key);
    if ($value === false || $value === '') {
        return $fallback;
    }
    return $value;
}

/**
 * Basic app configuration.
 * Defaults are tuned for local MySQL on localhost.
 */
define('MYSQL_HOST', env_or('MYSQL_HOST', '127.0.0.1'));
define('MYSQL_PORT', (int)env_or('MYSQL_PORT', '3306'));
define('MYSQL_DATABASE', env_or('MYSQL_DATABASE', 'nmillion'));
define('MYSQL_USERNAME', env_or('MYSQL_USERNAME', 'root'));
define('MYSQL_PASSWORD', env_or('MYSQL_PASSWORD', ''));
define('APP_BASE_URL', env_or('APP_BASE_URL', 'http://localhost:8000'));
define('TIINGO_API_KEY', env_or('TIINGO_API_KEY', ''));
define('ADMIN_EMAILS', env_or('ADMIN_EMAILS', ''));

// Google reCAPTCHA v2 test keys from Google docs (safe for local testing).
const RECAPTCHA_SITE_KEY = '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI';
const RECAPTCHA_SECRET_KEY = '6LdwDZErAAAAAAu3ew0MJAayoRUcBjUopToeHjp6';
